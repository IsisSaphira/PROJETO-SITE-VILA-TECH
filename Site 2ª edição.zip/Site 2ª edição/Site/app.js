// Função para adicionar produto ao carrinho
function adicionarAoCarrinho(nomeProduto) {
  // Cria um carrinho se ainda não existir no localStorage
  let carrinho = JSON.parse(localStorage.getItem("carrinho")) || [];

  // Verifica se o produto já foi adicionado
  if (!carrinho.includes(nomeProduto)) {
    carrinho.push(nomeProduto); // Adiciona o produto
    localStorage.setItem("carrinho", JSON.stringify(carrinho)); // Salva no localStorage

    alert(nomeProduto + " foi adicionado ao carrinho!"); // Exibe a mensagem
  } else {
    alert(nomeProduto + " já está no carrinho.");
  }
}

// Função para validar a compra no carrinho
function validarCompra() {
  let carrinho = JSON.parse(localStorage.getItem("carrinho")) || [];

  if (carrinho.length > 0) {
    alert("Você tem " + carrinho.length + " item(ns) no carrinho.");
    // Exibir o conteúdo do carrinho ou direcionar para o checkout
    console.log("Carrinho:", carrinho);
  } else {
    alert("Seu carrinho está vazio. Adicione itens para continuar.");
  }
}

// Função para scroll no carrossel de produtos
function scrollCarousel(direction) {
  const container = document.getElementById("carrosselProdutos");
  const scrollAmount = 250;
  container.scrollBy({
    left: direction * scrollAmount,
    behavior: 'smooth'
  });
}